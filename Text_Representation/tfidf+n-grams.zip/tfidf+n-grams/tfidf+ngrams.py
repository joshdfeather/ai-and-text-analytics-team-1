import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.sparse
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer 
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
from datasets import load_dataset


dataset = load_dataset("pubmed_qa", "pqa_labeled")

records = []
for row in dataset['train']:
    text = (
        f"Question: {row['question']} "
        f"Context: {' '.join(row['context']['contexts'])}"
    )
    label = row['final_decision']
    records.append({'text': text, 'label': label})
df = pd.DataFrame(records)

X_train, X_test, y_train, y_test = train_test_split(
    df['text'], df['label'], test_size=0.5, random_state=42, stratify=df['label']
)

ngram_vectorizer = TfidfVectorizer(stop_words='english', ngram_range=(1, 2))

X_train_ngram = ngram_vectorizer.fit_transform(X_train)
X_test_ngram = ngram_vectorizer.transform(X_test)

model = LogisticRegression(class_weight='balanced', max_iter=1000)
model.fit(X_train_ngram, y_train)

y_pred = model.predict(X_test_ngram)

acc = accuracy_score(y_test, y_pred)
macro_f1 = f1_score(y_test, y_pred, average='macro')
cm = confusion_matrix(y_test, y_pred)

scipy.sparse.save_npz('X_train_ngram.npz', X_train_ngram)
scipy.sparse.save_npz('X_test_ngram.npz', X_test_ngram)

plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', 
            xticklabels=model.classes_, 
            yticklabels=model.classes_, 
            cmap='Blues')

plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('TF-IDF + N-grams Confusion Matrix')
plt.savefig('tfidf_ngrams.png', bbox_inches='tight', dpi=300) 

current_path = os.getcwd()
plt.show()