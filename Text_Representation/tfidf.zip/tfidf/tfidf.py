import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.sparse
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer 
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
from datasets import load_dataset


dataset = load_dataset("pubmed_qa", "pqa_labeled")

records = []
for row in dataset['train']:
    text = (
        f"Question: {row['question']} "
        f"Context: {' '.join(row['context']['contexts'])}"
    )
    label = row['final_decision']
    records.append({'text': text, 'label': label})
df = pd.DataFrame(records)

X_train, X_test, y_train, y_test = train_test_split(
    df['text'], 
    df['label'], 
    test_size=0.5,       
    random_state=42, 
    stratify=df['label'] 
)


tfidf_vectorizer = TfidfVectorizer(stop_words='english')

X_train_tfidf = tfidf_vectorizer.fit_transform(X_train)
X_test_tfidf = tfidf_vectorizer.transform(X_test)


model = LogisticRegression(class_weight='balanced', max_iter=1000)
model.fit(X_train_tfidf, y_train)

y_pred = model.predict(X_test_tfidf)

acc = accuracy_score(y_test, y_pred)
macro_f1 = f1_score(y_test, y_pred, average='macro')
cm = confusion_matrix(y_test, y_pred)


scipy.sparse.save_npz('X_train_tfidf.npz', X_train_tfidf)
scipy.sparse.save_npz('X_test_tfidf.npz', X_test_tfidf)

np.save('y_train.npy', y_train.to_numpy())
np.save('y_test.npy', y_test.to_numpy())

plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', 
            xticklabels=model.classes_, 
            yticklabels=model.classes_, 
            cmap='Blues')

plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('TF-IDF Model Confusion Matrix')
plt.savefig('tfidf.png', bbox_inches='tight', dpi=300) 

plt.show()